<script setup>

</script>

<template>
    <div>
        <h1>Página Principal</h1>
        <p>Pagina principal de la web de pruebas.....</p>
        

    </div>
</template>

<style scoped>

</style>